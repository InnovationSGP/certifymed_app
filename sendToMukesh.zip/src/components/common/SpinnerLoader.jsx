import React from "react";

const SpinnerLoader = () => {
  return (
    <>
      <span className="spinner-loader"></span>
    </>
  );
};

export default SpinnerLoader;
